import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { RequestMethod } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Tudo vira /api/..., EXCETO GET / (de health check)
  app.setGlobalPrefix('api', {
    exclude: [{ path: '/', method: RequestMethod.GET }],
  });

  await app.listen(process.env.APP_PORT ? Number(process.env.APP_PORT) : 3000);
}
bootstrap();
